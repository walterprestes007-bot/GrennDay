package com.greenday.service;

import com.greenday.model.Clima;
import com.greenday.model.Propriedade;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.Map;

@Service
@RequiredArgsConstructor
public class ApiMeteorologicaService {

    private final RestClient restClient;
    private final ClimaService climaService;

    @Value("${greenday.clima.base-url:https://api.open-meteo.com/v1/forecast}")
    private String baseUrl;

    @SuppressWarnings("unchecked")
    public Clima buscarEArmazenarClimaAtual(Propriedade propriedade) {
        if (propriedade.getLatitude() == null || propriedade.getLongitude() == null) {
            throw new IllegalArgumentException("Cadastre latitude e longitude da propriedade para consultar o clima.");
        }

        String url = String.format(
            "%s?latitude=%s&longitude=%s&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code&timezone=auto",
            baseUrl, propriedade.getLatitude(), propriedade.getLongitude()
        );

        Map<String, Object> resposta = restClient.get()
            .uri(url)
            .retrieve()
            .body(Map.class);

        Map<String, Object> current = (Map<String, Object>) resposta.get("current");
        if (current == null) {
            throw new IllegalStateException("A API meteorológica não retornou condições atuais.");
        }

        Clima clima = Clima.builder()
            .propriedade(propriedade)
            .temperaturaCelsius(number(current.get("temperature_2m")))
            .umidadeRelativa(number(current.get("relative_humidity_2m")))
            .precipitacaoMm(number(current.get("precipitation")))
            .velocidadeVentoKmh(number(current.get("wind_speed_10m")))
            .descricao(descricaoWmo(current.get("weather_code")))
            .build();

        return climaService.registrar(propriedade.getId(), clima);
    }

    private Double number(Object value) {
        return value instanceof Number n ? n.doubleValue() : null;
    }

    private String descricaoWmo(Object codeValue) {
        if (!(codeValue instanceof Number n)) return "Condição não informada";
        return switch (n.intValue()) {
            case 0 -> "Céu limpo";
            case 1, 2, 3 -> "Parcialmente nublado";
            case 45, 48 -> "Névoa";
            case 51, 53, 55, 56, 57 -> "Chuvisco";
            case 61, 63, 65, 66, 67 -> "Chuva";
            case 71, 73, 75, 77 -> "Neve";
            case 80, 81, 82 -> "Pancadas de chuva";
            case 85, 86 -> "Pancadas de neve";
            case 95, 96, 99 -> "Trovoada";
            default -> "Condição variável";
        };
    }
}
