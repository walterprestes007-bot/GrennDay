package com.greenday.service;

import com.greenday.model.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class RelatorioService {

    private final PropriedadeService propriedadeService;
    private final CulturaService culturaService;
    private final SensorService sensorService;
    private final ClimaService climaService;
    private final AlertaService alertaService;
    private final IrrigacaoService irrigacaoService;

    public Map<String, Object> gerarResumoPropriedade(Long propriedadeId) {
        Propriedade propriedade = propriedadeService.buscarPorId(propriedadeId);
        List<Cultura> culturas = culturaService.listarPorPropriedade(propriedadeId);
        List<Sensor> sensores = sensorService.listarPorPropriedade(propriedadeId);
        List<Alerta> alertasNaoLidos = alertaService.listarNaoLidos(propriedadeId);
        List<Irrigacao> irrigacoes = irrigacaoService.listarPorPropriedade(propriedadeId);

        Clima climaAtual;
        try {
            climaAtual = climaService.ultimo(propriedadeId);
        } catch (Exception ignored) {
            climaAtual = null;
        }

        Map<String, Object> resumo = new HashMap<>();
        resumo.put("propriedade", propriedade.getNome());
        resumo.put("totalCulturas", culturas.size());
        resumo.put("totalSensores", sensores.size());
        resumo.put("alertasNaoLidos", alertasNaoLidos.size());
        resumo.put("totalIrrigacoes", irrigacoes.size());
        resumo.put("climaAtual", climaAtual);
        return resumo;
    }
}
