package com.greenday.controller;

import com.greenday.model.Irrigacao;
import com.greenday.model.Usuario;
import com.greenday.service.IrrigacaoService;
import com.greenday.service.PropriedadeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/propriedades/{propriedadeId}/irrigacoes")
@RequiredArgsConstructor
public class IrrigacaoController {

    private final IrrigacaoService irrigacaoService;
    private final PropriedadeService propriedadeService;

    @PostMapping
    public ResponseEntity<Irrigacao> agendar(@PathVariable Long propriedadeId,
                                             @RequestBody Irrigacao irrigacao,
                                             @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(irrigacaoService.agendar(propriedadeId, irrigacao));
    }

    @GetMapping
    public ResponseEntity<List<Irrigacao>> listar(@PathVariable Long propriedadeId,
                                                  @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(irrigacaoService.listarPorPropriedade(propriedadeId));
    }

    @PatchMapping("/{id}/iniciar")
    public ResponseEntity<Irrigacao> iniciar(@PathVariable Long propriedadeId,
                                             @PathVariable Long id,
                                             @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(irrigacaoService.iniciar(id));
    }

    @PatchMapping("/{id}/concluir")
    public ResponseEntity<Irrigacao> concluir(@PathVariable Long propriedadeId,
                                              @PathVariable Long id,
                                              @RequestBody Map<String, Double> corpo,
                                              @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(irrigacaoService.concluir(id, corpo.get("volumeLitros")));
    }

    @PatchMapping("/{id}/cancelar")
    public ResponseEntity<Irrigacao> cancelar(@PathVariable Long propriedadeId,
                                              @PathVariable Long id,
                                              @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(irrigacaoService.cancelar(id));
    }
}
