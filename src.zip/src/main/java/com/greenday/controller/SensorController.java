package com.greenday.controller;

import com.greenday.dto.SensorDTO;
import com.greenday.model.DadosSensor;
import com.greenday.model.Sensor;
import com.greenday.model.Usuario;
import com.greenday.service.PropriedadeService;
import com.greenday.service.SensorService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/propriedades/{propriedadeId}/sensores")
@RequiredArgsConstructor
public class SensorController {

    private final SensorService sensorService;
    private final PropriedadeService propriedadeService;

    @PostMapping
    public ResponseEntity<SensorDTO> criar(@PathVariable Long propriedadeId,
                                           @RequestBody Sensor sensor,
                                           @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(SensorDTO.fromEntity(sensorService.criar(propriedadeId, sensor)));
    }

    @GetMapping
    public ResponseEntity<List<SensorDTO>> listar(@PathVariable Long propriedadeId,
                                                  @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        List<SensorDTO> sensores = sensorService.listarPorPropriedade(propriedadeId).stream()
            .map(sensor -> {
                SensorDTO dto = SensorDTO.fromEntity(sensor);
                dto.setUltimaLeitura(sensorService.ultimaLeitura(sensor.getId()).orElse(null));
                return dto;
            })
            .toList();
        return ResponseEntity.ok(sensores);
    }

    @GetMapping("/{id}/historico")
    public ResponseEntity<List<DadosSensor>> historico(@PathVariable Long propriedadeId,
                                                       @PathVariable Long id,
                                                       @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(sensorService.historico(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<SensorDTO> atualizar(@PathVariable Long propriedadeId,
                                                @PathVariable Long id,
                                                @RequestBody Sensor dados,
                                                @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(SensorDTO.fromEntity(sensorService.atualizar(id, dados)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long propriedadeId,
                                        @PathVariable Long id,
                                        @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        sensorService.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
