package com.greenday.controller;

import com.greenday.model.Cultura;
import com.greenday.model.Usuario;
import com.greenday.service.CulturaService;
import com.greenday.service.PropriedadeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/propriedades/{propriedadeId}/culturas")
@RequiredArgsConstructor
public class CulturaController {

    private final CulturaService culturaService;
    private final PropriedadeService propriedadeService;

    @PostMapping
    public ResponseEntity<Cultura> criar(@PathVariable Long propriedadeId,
                                         @RequestBody Cultura cultura,
                                         @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(culturaService.criar(propriedadeId, cultura));
    }

    @GetMapping
    public ResponseEntity<List<Cultura>> listar(@PathVariable Long propriedadeId,
                                                @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(culturaService.listarPorPropriedade(propriedadeId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Cultura> atualizar(@PathVariable Long propriedadeId,
                                             @PathVariable Long id,
                                             @RequestBody Cultura dados,
                                             @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(culturaService.atualizar(id, dados));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long propriedadeId,
                                        @PathVariable Long id,
                                        @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        culturaService.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
