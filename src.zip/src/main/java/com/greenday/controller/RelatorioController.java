package com.greenday.controller;

import com.greenday.model.Recomendacao;
import com.greenday.model.Usuario;
import com.greenday.service.PropriedadeService;
import com.greenday.service.RecomendacaoService;
import com.greenday.service.RelatorioService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/propriedades/{propriedadeId}/relatorios")
@RequiredArgsConstructor
public class RelatorioController {

    private final RelatorioService relatorioService;
    private final RecomendacaoService recomendacaoService;
    private final PropriedadeService propriedadeService;

    @GetMapping("/resumo")
    public ResponseEntity<Map<String, Object>> resumo(@PathVariable Long propriedadeId,
                                                      @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(relatorioService.gerarResumoPropriedade(propriedadeId));
    }

    @GetMapping("/recomendacoes")
    public ResponseEntity<List<Recomendacao>> recomendacoes(@PathVariable Long propriedadeId,
                                                            @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(recomendacaoService.gerarParaPropriedade(propriedadeId));
    }
}
