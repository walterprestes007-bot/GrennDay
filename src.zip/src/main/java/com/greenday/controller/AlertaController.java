package com.greenday.controller;

import com.greenday.model.Alerta;
import com.greenday.model.Usuario;
import com.greenday.service.AlertaService;
import com.greenday.service.PropriedadeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/propriedades/{propriedadeId}/alertas")
@RequiredArgsConstructor
public class AlertaController {

    private final AlertaService alertaService;
    private final PropriedadeService propriedadeService;

    @GetMapping
    public ResponseEntity<List<Alerta>> listar(@PathVariable Long propriedadeId,
                                               @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(alertaService.listarPorPropriedade(propriedadeId));
    }

    @GetMapping("/nao-lidos")
    public ResponseEntity<List<Alerta>> naoLidos(@PathVariable Long propriedadeId,
                                                 @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(alertaService.listarNaoLidos(propriedadeId));
    }

    @PatchMapping("/{id}/marcar-lido")
    public ResponseEntity<Alerta> marcarLido(@PathVariable Long propriedadeId,
                                             @PathVariable Long id,
                                             @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(alertaService.marcarComoLido(id));
    }
}
