package com.greenday.controller;

import com.greenday.dto.ClimaDTO;
import com.greenday.model.Clima;
import com.greenday.model.Propriedade;
import com.greenday.model.Usuario;
import com.greenday.service.ApiMeteorologicaService;
import com.greenday.service.ClimaService;
import com.greenday.service.PropriedadeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/propriedades/{propriedadeId}/clima")
@RequiredArgsConstructor
public class ClimaController {

    private final ClimaService climaService;
    private final ApiMeteorologicaService apiMeteorologicaService;
    private final PropriedadeService propriedadeService;

    @GetMapping("/atual")
    public ResponseEntity<ClimaDTO> atual(@PathVariable Long propriedadeId,
                                          @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        return ResponseEntity.ok(ClimaDTO.fromEntity(climaService.ultimo(propriedadeId)));
    }

    @GetMapping("/historico")
    public ResponseEntity<List<ClimaDTO>> historico(@PathVariable Long propriedadeId,
                                                    @AuthenticationPrincipal Usuario usuario) {
        propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        List<ClimaDTO> historico = climaService.historico(propriedadeId).stream()
            .map(ClimaDTO::fromEntity)
            .toList();
        return ResponseEntity.ok(historico);
    }

    @PostMapping("/atualizar")
    public ResponseEntity<ClimaDTO> atualizarViaApiExterna(@PathVariable Long propriedadeId,
                                                           @AuthenticationPrincipal Usuario usuario) {
        Propriedade propriedade = propriedadeService.buscarDoUsuario(propriedadeId, usuario);
        Clima clima = apiMeteorologicaService.buscarEArmazenarClimaAtual(propriedade);
        return ResponseEntity.ok(ClimaDTO.fromEntity(clima));
    }
}
