function getPropertyId() {
  const params = new URLSearchParams(location.search);
  const fromUrl = params.get('propriedadeId');
  if (fromUrl) localStorage.setItem('greenday_propriedade_id', fromUrl);
  return fromUrl || localStorage.getItem('greenday_propriedade_id');
}
function authHeaders(extra = {}) {
  const token = localStorage.getItem('greenday_token');
  const headers = {...extra};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (!headers['Content-Type'] && extra.__json) {
    headers['Content-Type'] = 'application/json';
    delete headers.__json;
  }
  return headers;
}
async function api(url, options = {}) {
  const opts = {...options, headers: authHeaders(options.headers || {})};
  const response = await fetch(url, opts);
  if (response.status === 401) {
    localStorage.removeItem('greenday_token');
    location.href = '/login';
    throw new Error('Sessão expirada.');
  }
  if (!response.ok) {
    let message = 'Não foi possível concluir a operação.';
    try {
      const data = await response.json();
      message = data.mensagem || data.erro || message;
    } catch {}
    throw new Error(message);
  }
  if (response.status === 204) return null;
  return response.json();
}
function toast(message, kind='ok') {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = message;
  el.style.background = kind === 'error' ? '#8f3737' : '#1f2d24';
  el.classList.add('show');
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => el.classList.remove('show'), 3000);
}
function setLoading(el, text='Carregando...') {
  if (el) el.innerHTML = `<div class="loading"><span class="spinner"></span>${text}</div>`;
}
async function loadUser() {
  return api('/api/usuarios/me');
}
async function loadProperties() {
  return api('/api/propriedades');
}
function goPage(path) {
  const id = getPropertyId();
  location.href = id ? `${path}?propriedadeId=${encodeURIComponent(id)}` : path;
}
document.addEventListener('DOMContentLoaded', async () => {
  document.querySelectorAll('[data-mobile-toggle]').forEach(btn => btn.addEventListener('click', () => {
    document.querySelector('.sidebar')?.classList.toggle('open');
  }));
  const currentPath = location.pathname;
  document.querySelectorAll('[data-page]').forEach(link => {
    const page = link.dataset.page;
    const expected = page === 'dashboard' ? '/dashboard' : `/${page}`;
    if (currentPath === expected) link.classList.add('active');
  });

  document.querySelectorAll('[data-property-link]').forEach(link => {
    link.addEventListener('click', e => {
      const id = getPropertyId();
      if (!id && link.dataset.propertyLink !== 'properties') {
        e.preventDefault();
        location.href = '/propriedades';
      }
    });
  });
  document.querySelector('#btn-logout')?.addEventListener('click', () => {
    localStorage.removeItem('greenday_token');
    localStorage.removeItem('greenday_propriedade_id');
    location.href = '/logout';
  });
});

async function initAppChrome() {
  try {
    const user = await loadUser();
    document.querySelectorAll('[data-user-name]').forEach(el => el.textContent = user.nome || 'Usuário');
    document.querySelectorAll('[data-user-role]').forEach(el => el.textContent = user.role || 'PRODUTOR');
    if (user.role === 'ADMIN') {
      document.querySelectorAll('[data-admin-only]').forEach(el => el.style.display = '');
    }
  } catch (e) {
    return;
  }

  const selects = document.querySelectorAll('[data-property-select]');
  if (!selects.length) return;

  const list = await loadProperties();
  const current = getPropertyId() || (list[0]?.id?.toString() || '');
  if (current) localStorage.setItem('greenday_propriedade_id', current);

  selects.forEach(select => {
    select.innerHTML = list.length
      ? list.map(p => `<option value="${p.id}" ${String(p.id)===String(current)?'selected':''}>${p.nome}</option>`).join('')
      : '<option value="">Nenhuma propriedade';
    select.onchange = () => {
      const id = select.value;
      if (!id) return;
      localStorage.setItem('greenday_propriedade_id', id);
      const params = new URLSearchParams(location.search);
      params.set('propriedadeId', id);
      location.href = location.pathname + '?' + params.toString();
    };
  });

  const currentPath = location.pathname;
  document.querySelectorAll('[data-page]').forEach(link => {
    const page = link.dataset.page;
    const expected = page === 'dashboard' ? '/dashboard' : `/${page}`;
    if (currentPath === expected) link.classList.add('active');
  });

  document.querySelectorAll('[data-property-link]').forEach(link => {
    if (link.dataset.propertyLink === 'properties') return;
    const id = getPropertyId();
    if (id) {
      const url = new URL(link.getAttribute('href'), location.origin);
      url.searchParams.set('propriedadeId', id);
      link.setAttribute('href', url.pathname + url.search);
    } else {
      link.setAttribute('href', '/propriedades');
    }
  });
}
