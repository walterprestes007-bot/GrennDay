const pid = getPropertyId(); let culturaEdit = null;
async function carregarCulturas(){
 const tbody=document.getElementById('tabela-culturas');
 if(!pid){tbody.innerHTML='<tr><td colspan="6" class="empty">Selecione uma propriedade.</td></tr>';return}
 try{
  const list=await api(`/api/propriedades/${pid}/culturas`);
  document.getElementById('cultura-count').textContent=`${list.length} registro(s)`;
  tbody.innerHTML=list.map(c=>`<tr><td><b>${c.nome}</b></td><td>${c.variedade||'—'}</td><td>${c.dataPlantio?new Date(c.dataPlantio+'T00:00').toLocaleDateString('pt-BR'):'—'}</td><td>${c.previsaoColheita?new Date(c.previsaoColheita+'T00:00').toLocaleDateString('pt-BR'):'—'}</td><td>${c.areaOcupadaHectares??'—'} ha</td><td><button class="btn btn-soft" style="padding:7px 9px" onclick='editarCultura(${JSON.stringify(c)})'>Editar</button> <button class="btn btn-danger" style="padding:7px 9px" onclick="excluirCultura(${c.id})">Excluir</button></td></tr>`).join('')||'<tr><td colspan="6" class="empty">Nenhuma cultura cadastrada.</td></tr>';
 }catch(e){tbody.innerHTML=`<tr><td colspan="6" class="empty">${e.message}</td></tr>`}
}
function mostrarCultura(c=null){culturaEdit=c?.id||null;document.getElementById('cultura-form-box').style.display='';document.getElementById('cultura-form-title').textContent=c?'Editar cultura':'Nova cultura';document.getElementById('cultura-id').value=c?.id||'';document.getElementById('cultura-nome').value=c?.nome||'';document.getElementById('cultura-variedade').value=c?.variedade||'';document.getElementById('cultura-plantio').value=c?.dataPlantio||'';document.getElementById('cultura-colheita').value=c?.previsaoColheita||'';document.getElementById('cultura-area').value=c?.areaOcupadaHectares??''}
document.getElementById('toggle-cultura').onclick=()=>mostrarCultura(); document.getElementById('cancel-cultura').onclick=()=>document.getElementById('cultura-form-box').style.display='none';
window.editarCultura=mostrarCultura;
window.excluirCultura=async id=>{if(!confirm('Excluir esta cultura?'))return;try{await api(`/api/propriedades/${pid}/culturas/${id}`,{method:'DELETE'});toast('Cultura excluída.');carregarCulturas()}catch(e){toast(e.message,'error')}};
document.getElementById('form-cultura').onsubmit=async e=>{e.preventDefault();const body={nome:document.getElementById('cultura-nome').value.trim(),variedade:document.getElementById('cultura-variedade').value.trim()||null,dataPlantio:document.getElementById('cultura-plantio').value||null,previsaoColheita:document.getElementById('cultura-colheita').value||null,areaOcupadaHectares:Number(document.getElementById('cultura-area').value)||null};try{await api(culturaEdit?`/api/propriedades/${pid}/culturas/${culturaEdit}`:`/api/propriedades/${pid}/culturas`,{method:culturaEdit?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});toast(culturaEdit?'Cultura atualizada!':'Cultura criada!');document.getElementById('cultura-form-box').style.display='none';carregarCulturas()}catch(e){toast(e.message,'error')}};
carregarCulturas();
