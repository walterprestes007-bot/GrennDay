let editingPropertyId = null;

async function carregarPropriedades() {
  const box = document.getElementById('lista-propriedades');
  setLoading(box, 'Carregando propriedades...');
  try {
    const list = await loadProperties();
    if (!list.length) {
      box.innerHTML = `<div class="panel empty" style="grid-column:1/-1"><strong>Você ainda não possui propriedades</strong>Cadastre a primeira para liberar culturas, sensores, clima e irrigação.</div>`;
      return;
    }
    box.innerHTML = list.map((p, i) => `
      <article class="entity" style="animation-delay:${i*60}ms">
        <div style="display:flex;justify-content:space-between;gap:10px;align-items:center">
          <h3>🌿 ${p.nome}</h3><span class="badge">${p.areaHectares ?? '—'} ha</span>
        </div>
        <p>${p.endereco || 'Localização não informada'}<br>${p.latitude && p.longitude ? `Coordenadas: ${p.latitude}, ${p.longitude}` : 'Coordenadas não informadas'}</p>
        <div class="entity-actions">
          <a class="btn btn-primary" style="padding:9px 11px" href="/dashboard?propriedadeId=${p.id}">Abrir dashboard</a>
          <button class="btn btn-soft" style="padding:9px 11px" onclick='editarPropriedade(${JSON.stringify(p)})'>Editar</button>
          <button class="btn btn-danger" style="padding:9px 11px" onclick="excluirPropriedade(${p.id})">Excluir</button>
        </div>
      </article>`).join('');
  } catch(e) { box.innerHTML = `<div class="panel empty" style="grid-column:1/-1">${e.message}</div>`; }
}

function abrirForm(p = null) {
  editingPropertyId = p?.id || null;
  document.getElementById('property-form').style.display = '';
  document.getElementById('property-form-title').textContent = p ? 'Editar propriedade' : 'Cadastrar propriedade';
  document.getElementById('property-id').value = p?.id || '';
  document.getElementById('property-nome').value = p?.nome || '';
  document.getElementById('property-area').value = p?.areaHectares ?? '';
  document.getElementById('property-endereco').value = p?.endereco || '';
  document.getElementById('property-lat').value = p?.latitude ?? '';
  document.getElementById('property-lon').value = p?.longitude ?? '';
  window.scrollTo({top:0,behavior:'smooth'});
}
document.getElementById('btn-nova-propriedade').onclick = () => abrirForm();
document.getElementById('cancel-property').onclick = () => document.getElementById('property-form').style.display='none';

async function editarPropriedade(p){ abrirForm(p); }
async function excluirPropriedade(id){
  if(!confirm('Excluir esta propriedade? Todos os dados vinculados poderão ser removidos.')) return;
  try{ await api(`/api/propriedades/${id}`,{method:'DELETE'}); toast('Propriedade excluída.'); await carregarPropriedades(); }
  catch(e){toast(e.message,'error')}
}
document.getElementById('form-property').onsubmit = async e => {
  e.preventDefault();
  const body={nome:document.getElementById('property-nome').value.trim(),
    endereco:document.getElementById('property-endereco').value.trim()||null,
    areaHectares:Number(document.getElementById('property-area').value)||null,
    latitude:Number(document.getElementById('property-lat').value)||null,
    longitude:Number(document.getElementById('property-lon').value)||null};
  try{
    if(editingPropertyId) await api(`/api/propriedades/${editingPropertyId}`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    else { const p=await api('/api/propriedades',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}); localStorage.setItem('greenday_propriedade_id',p.id); }
    toast(editingPropertyId?'Propriedade atualizada!':'Propriedade criada!');
    document.getElementById('property-form').style.display='none'; await carregarPropriedades();
  } catch(e){toast(e.message,'error')}
};
carregarPropriedades();
