// Contexto compartilhado entre as paginas do GreenDay.
// Resolve qual propriedade esta selecionada (via URL ou localStorage) e mantem
// esse contexto ao navegar pelo menu, para as paginas nao "perderem" a
// propriedade escolhida quando o usuario clica em Culturas, Sensores, etc.

function obterPropriedadeId() {
    const params = new URLSearchParams(window.location.search);
    let id = params.get('propriedadeId');

    if (id) {
        localStorage.setItem('greenday_propriedade_id', id);
    } else {
        id = localStorage.getItem('greenday_propriedade_id');
    }

    return id;
}

function cabecalhosAutenticados(extra) {
    const token = localStorage.getItem('greenday_token');
    return Object.assign({ Authorization: `Bearer ${token}` }, extra || {});
}

// Mostra um aviso padrao quando a pagina depende de uma propriedade selecionada
// e nenhuma foi escolhida ainda.
function avisarSemPropriedade(elementId) {
    const el = document.getElementById(elementId);
    if (el) {
        el.innerHTML = '<p>Nenhuma propriedade selecionada. <a href="/propriedades">Escolha uma propriedade</a> para continuar.</p>';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const propriedadeId = obterPropriedadeId();
    if (!propriedadeId) return;

    // Propaga o ?propriedadeId=... para os links do menu que dependem dele
    document.querySelectorAll('nav.navbar a[href]').forEach((link) => {
        const url = new URL(link.getAttribute('href'), window.location.origin);
        const paginasSemPropriedade = ['/propriedades'];
        if (paginasSemPropriedade.includes(url.pathname)) return;
        url.searchParams.set('propriedadeId', propriedadeId);
        link.setAttribute('href', url.pathname + url.search);
    });
});
