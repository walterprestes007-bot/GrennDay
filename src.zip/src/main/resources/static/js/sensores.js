const propriedadeId = obterPropriedadeId();
const headers = cabecalhosAutenticados({ 'Content-Type': 'application/json' });

async function carregarSensores() {
    const sensores = await fetch(`/api/propriedades/${propriedadeId}/sensores`, { headers }).then(r => r.json());
    document.getElementById('lista-sensores').innerHTML = sensores.map(s => `
        <div class="card">
            <h3>${s.nome}</h3>
            <p>${s.tipo}</p>
            <p>Unidade: ${s.unidadeMedida ?? '-'}</p>
            <a href="#" onclick="verHistorico(${s.id}); return false;">Ver historico</a>
            <button onclick="editarSensor(${s.id}, '${(s.nome ?? '').replace(/'/g, "\\'")}', '${s.tipo}', '${(s.unidadeMedida ?? '').replace(/'/g, "\\'")}')">Editar</button>
            <button onclick="excluirSensor(${s.id})">Excluir</button>
        </div>`).join('');
}

async function editarSensor(id, nomeAtual, tipoAtual, unidadeAtual) {
    const nome = prompt('Nome do sensor:', nomeAtual);
    if (!nome) return;
    const tipo = prompt('Tipo (UMIDADE_SOLO, TEMPERATURA, LUMINOSIDADE, PH_SOLO, CHUVA):', tipoAtual);
    if (!tipo) return;
    const unidadeMedida = prompt('Unidade de medida:', unidadeAtual ?? '');
    await fetch(`/api/propriedades/${propriedadeId}/sensores/${id}`, { method: 'PUT', headers, body: JSON.stringify({ nome, tipo, unidadeMedida }) });
    carregarSensores();
}

async function excluirSensor(id) {
    if (!confirm('Excluir este sensor?')) return;
    await fetch(`/api/propriedades/${propriedadeId}/sensores/${id}`, { method: 'DELETE', headers });
    carregarSensores();
}

async function verHistorico(id) {
    const historico = await fetch(`/api/propriedades/${propriedadeId}/sensores/${id}/historico`, { headers }).then(r => r.json());
    const linhas = historico.map(h => `${h.medidoEm}: ${h.valor}`).join('\n') || 'Sem leituras registradas.';
    alert(linhas);
}

document.getElementById('btn-novo-sensor')?.addEventListener('click', async () => {
    const nome = prompt('Nome do sensor:');
    const tipo = prompt('Tipo (UMIDADE_SOLO, TEMPERATURA, LUMINOSIDADE, PH_SOLO, CHUVA):');
    if (!nome || !tipo) return;
    await fetch(`/api/propriedades/${propriedadeId}/sensores`, { method: 'POST', headers, body: JSON.stringify({ nome, tipo }) });
    carregarSensores();
});

if (propriedadeId) carregarSensores(); else avisarSemPropriedade('lista-sensores');
