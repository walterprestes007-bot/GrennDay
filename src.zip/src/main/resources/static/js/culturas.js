const propriedadeId = obterPropriedadeId();
const headers = cabecalhosAutenticados({ 'Content-Type': 'application/json' });

async function carregarCulturas() {
    const culturas = await fetch(`/api/propriedades/${propriedadeId}/culturas`, { headers }).then(r => r.json());
    const tbody = document.querySelector('#tabela-culturas tbody');
    tbody.innerHTML = culturas.map(c => `
        <tr>
            <td>${c.nome}</td><td>${c.variedade ?? '-'}</td>
            <td>${c.dataPlantio ?? '-'}</td><td>${c.previsaoColheita ?? '-'}</td>
            <td>${c.areaOcupadaHectares ?? '-'}</td>
            <td>
                <button onclick="editarCultura(${c.id}, '${(c.nome ?? '').replace(/'/g, "\\'")}', '${(c.variedade ?? '').replace(/'/g, "\\'")}')">Editar</button>
                <button onclick="excluirCultura(${c.id})">Excluir</button>
            </td>
        </tr>`).join('');
}

async function editarCultura(id, nomeAtual, variedadeAtual) {
    const nome = prompt('Nome da cultura:', nomeAtual);
    if (!nome) return;
    const variedade = prompt('Variedade:', variedadeAtual ?? '');
    await fetch(`/api/propriedades/${propriedadeId}/culturas/${id}`, { method: 'PUT', headers, body: JSON.stringify({ nome, variedade }) });
    carregarCulturas();
}

async function excluirCultura(id) {
    if (!confirm('Excluir esta cultura?')) return;
    await fetch(`/api/propriedades/${propriedadeId}/culturas/${id}`, { method: 'DELETE', headers });
    carregarCulturas();
}

document.getElementById('btn-nova-cultura')?.addEventListener('click', async () => {
    const nome = prompt('Nome da cultura:');
    if (!nome) return;
    await fetch(`/api/propriedades/${propriedadeId}/culturas`, { method: 'POST', headers, body: JSON.stringify({ nome }) });
    carregarCulturas();
});

if (propriedadeId) carregarCulturas(); else avisarSemPropriedade('tabela-culturas');
