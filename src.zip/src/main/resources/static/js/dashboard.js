let properties = [];

async function loadDashboard() {
  const user = await loadUser();
  document.getElementById('user-name').textContent = user.nome || 'Usuário';
  document.getElementById('hello-name').textContent = (user.nome || 'produtor').split(' ')[0];
  document.getElementById('user-role').textContent = user.role || 'PRODUTOR';

  if (user.role === 'ADMIN') {
    document.getElementById('admin-section').style.display = '';
    document.getElementById('admin-nav').style.display = '';
  }

  properties = await loadProperties();
  const select = document.getElementById('property-select');
  if (!properties.length) {
    select.innerHTML = '<option>Nenhuma propriedade</option>';
    document.getElementById('property-summary').innerHTML = `
      <div class="empty" style="grid-column:1/-1"><strong>Comece pela sua primeira propriedade</strong>
      <a class="btn btn-primary" href="/propriedades" style="margin-top:12px">Criar propriedade</a></div>`;
    document.getElementById('alertas-list').innerHTML = '<div class="empty">Cadastre uma propriedade para ativar o monitoramento.</div>';
    return;
  }

  const current = getPropertyId() || properties[0].id.toString();
  localStorage.setItem('greenday_propriedade_id', current);
  select.innerHTML = properties.map(p => `<option value="${p.id}" ${String(p.id)===String(current)?'selected':''}>${p.nome}</option>`).join('');
  select.onchange = () => {
    localStorage.setItem('greenday_propriedade_id', select.value);
    location.href = '/dashboard?propriedadeId=' + encodeURIComponent(select.value);
  };

  const property = properties.find(p => String(p.id)===String(current)) || properties[0];
  renderProperty(property);
  await Promise.all([loadSummary(property.id), loadWeather(property.id), loadAlerts(property.id)]);
}

function renderProperty(p) {
  document.getElementById('property-summary').innerHTML = `
    <div class="mini-kpi"><span>Nome</span><b>${p.nome || '—'}</b></div>
    <div class="mini-kpi"><span>Área</span><b>${p.areaHectares ?? '—'} ha</b></div>
    <div class="mini-kpi"><span>Local</span><b>${p.endereco || 'Não informado'}</b></div>`;
}

async function loadSummary(id) {
  const data = await api(`/api/propriedades/${id}/dashboard`);
  document.getElementById('total-culturas').textContent = data.totalCulturas ?? 0;
  document.getElementById('total-sensores').textContent = data.totalSensores ?? 0;
  document.getElementById('total-alertas').textContent = data.alertasNaoLidos ?? 0;
  document.getElementById('total-irrigacoes').textContent = data.totalIrrigacoes ?? 0;
}

async function loadWeather(id) {
  try {
    const c = await api(`/api/propriedades/${id}/clima/atual`);
    document.getElementById('weather-temp').textContent = `${Number(c.temperaturaCelsius).toFixed(1)}°C`;
    document.getElementById('weather-desc').textContent = c.descricao || 'Clima registrado';
    document.getElementById('weather-humidity').textContent = `${c.umidadeRelativa ?? '—'}%`;
    document.getElementById('weather-wind').textContent = `${c.velocidadeVentoKmh ?? '—'} km/h`;
    document.getElementById('weather-updated').textContent = c.coletadoEm ? new Date(c.coletadoEm).toLocaleString('pt-BR') : '—';
  } catch {
    document.getElementById('weather-temp').textContent = '—';
    document.getElementById('weather-desc').textContent = 'Ainda não há dados climáticos. Abra a tela Clima para atualizar.';
  }
}

async function loadAlerts(id) {
  const list = document.getElementById('alertas-list');
  try {
    const alerts = await api(`/api/propriedades/${id}/alertas/nao-lidos`);
    list.innerHTML = alerts.slice(0, 5).map(a => `
      <div class="alert-item">
        <span class="dot ${String(a.severidade||'').toLowerCase()}"></span>
        <div><b>${a.tipo || 'Alerta'} · ${a.severidade || 'BAIXA'}</b><p>${a.mensagem || 'Sem descrição.'}</p></div>
      </div>`).join('') || '<div class="empty">Tudo certo por aqui. Nenhum alerta não lido.</div>';
  } catch (e) {
    list.innerHTML = `<div class="empty">${e.message}</div>`;
  }
}

loadDashboard().catch(err => {
  toast(err.message, 'error');
  setTimeout(() => location.href='/login', 900);
});
