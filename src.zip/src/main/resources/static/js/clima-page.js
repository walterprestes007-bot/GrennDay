const pidClima=getPropertyId();
async function carregarClima(){
 if(!pidClima)return;
 try{
   const c=await api(`/api/propriedades/${pidClima}/clima/atual`);
   document.getElementById('clima-temp').textContent=c.temperaturaCelsius==null?'—':`${Number(c.temperaturaCelsius).toFixed(1)}°C`;
   document.getElementById('clima-desc').textContent=c.descricao||'Condições registradas';
   document.getElementById('clima-umidade').textContent=`${c.umidadeRelativa??'—'}%`;
   document.getElementById('clima-chuva').textContent=`${c.precipitacaoMm??'—'} mm`;
   document.getElementById('clima-vento').textContent=`${c.velocidadeVentoKmh??'—'} km/h`;
   document.getElementById('clima-status').innerHTML=`<strong>Dados atualizados</strong><br>${c.coletadoEm?new Date(c.coletadoEm).toLocaleString('pt-BR'):'—'}`;
 }catch{document.getElementById('clima-desc').textContent='Ainda não há dados. Use “Atualizar agora” para consultar a API meteorológica.';document.getElementById('clima-status').textContent='Nenhuma coleta registrada.'}
 try{
   const h=await api(`/api/propriedades/${pidClima}/clima/historico`);
   document.getElementById('clima-history').innerHTML=h.map(c=>`<tr><td>${c.coletadoEm?new Date(c.coletadoEm).toLocaleString('pt-BR'):'—'}</td><td>${c.temperaturaCelsius??'—'}°C</td><td>${c.umidadeRelativa??'—'}%</td><td>${c.precipitacaoMm??'—'} mm</td><td>${c.velocidadeVentoKmh??'—'} km/h</td></tr>`).join('')||'<tr><td colspan="5" class="empty">Sem histórico disponível.</td></tr>';
 }catch(e){document.getElementById('clima-history').innerHTML=`<tr><td colspan="5" class="empty">${e.message}</td></tr>`}
}
document.getElementById('btn-atualizar-clima').onclick=async()=>{try{const b=document.getElementById('btn-atualizar-clima');b.disabled=true;b.textContent='Atualizando...';await api(`/api/propriedades/${pidClima}/clima/atualizar`,{method:'POST'});toast('Clima atualizado!');await carregarClima()}catch(e){toast(e.message,'error')}finally{document.getElementById('btn-atualizar-clima').disabled=false;document.getElementById('btn-atualizar-clima').textContent='↻ Atualizar agora'}};
carregarClima();
